/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Angel
 */
public class PEDIDO {
    private int CODIGO_PEDIDO;
    private String TIPO_SERVICIO;
    private String FECHA;

    public PEDIDO(int CODIGO_PEDIDO, String TIPO_SERVICIO, String FECHA) {
        this.CODIGO_PEDIDO = CODIGO_PEDIDO;
        this.TIPO_SERVICIO = TIPO_SERVICIO;
        this.FECHA = FECHA;
    }

    public int getCODIGO_PEDIDO() {
        return CODIGO_PEDIDO;
    }

    public String getTIPO_SERVICIO() {
        return TIPO_SERVICIO;   
    }

    public String getFECHA() {
        return FECHA;
    }
    
    
}
