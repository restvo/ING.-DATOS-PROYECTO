
package Clases;


public class CAMION {
    
    private String VIN;
    private int COD_RUT;
    private int COD_EMPLEADO;
    private String MARCA;
    private String MODELO;
    private String DISPONIBILIDAD;
    private int CAPACIDAD_MAXIMA;

    public CAMION(String VIN, int COD_RUT, int COD_EMPLEADO, String MARCA, String MODELO, String DISPONIBILIDAD, int CAPACIDAD_MAXIMA) {
        this.VIN = VIN;
        this.COD_RUT = COD_RUT;
        this.COD_EMPLEADO = COD_EMPLEADO;
        this.MARCA = MARCA;
        this.MODELO = MODELO;
        this.DISPONIBILIDAD = DISPONIBILIDAD;
        this.CAPACIDAD_MAXIMA = CAPACIDAD_MAXIMA;
    }

    public String getVIN() {
        return VIN;
    }

    public int getCOD_RUT() {
        return COD_RUT;
    }

    public int getCOD_EMPLEADO() {
        return COD_EMPLEADO;
    }

    public String getMARCA() {
        return MARCA;
    }

    public String getMODELO() {
        return MODELO;
    }

    public String getDISPONIBILIDAD() {
        return DISPONIBILIDAD;
    }

    public int getCAPACIDAD_MAXIMA() {
        return CAPACIDAD_MAXIMA;
    }
    
}
