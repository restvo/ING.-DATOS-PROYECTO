/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


public class EVENTO {
    private int COD_EVENTO;
    private int COD_RUT;
    private String DESCRIPCION_EVE;
    private int TIEMPO_ESPERA;

    public EVENTO(int COD_EVENTO, int COD_RUT, String DESCRIPCION_EVE,int TIEMPO_ESPERA) {
        this.COD_EVENTO = COD_EVENTO;
        this.COD_RUT = COD_RUT;
        this.DESCRIPCION_EVE = DESCRIPCION_EVE;
        this.TIEMPO_ESPERA = TIEMPO_ESPERA;
    }

    public int getCOD_EVENTO() {
        return COD_EVENTO;
    }
    
    public int getCOD_RUT() {
        return COD_RUT;
    }

    public String getDESCRIPCION_EVE() {
        return DESCRIPCION_EVE;
    }

    public int getTIEMPO_ESPERA() {
        return TIEMPO_ESPERA;
    }
    
       
}
