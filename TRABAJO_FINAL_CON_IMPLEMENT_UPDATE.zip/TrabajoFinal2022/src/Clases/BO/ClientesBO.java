/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases.BO;

import DAO.ClienteDAO;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JTable;

/**
 *
 * @author Angel
 */
public class ClientesBO {
    public ClienteDAO cliDAO = new ClienteDAO();
    
        public void listarCliente(JTable tabla)
    {
        Connection conn = JdbcUtil.getConnection();
        cliDAO.listarCliente(conn, tabla);
        try {
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
