/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases.BO;

import DAO.PedidoDAO;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JTable;

public class PedidosBO {
    public PedidoDAO pedDAO = new PedidoDAO();
    
        public void listarPedido(JTable tabla)
    {
        Connection conn = JdbcUtil.getConnection();
        pedDAO.listarPedido(conn, tabla);
        try {
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
