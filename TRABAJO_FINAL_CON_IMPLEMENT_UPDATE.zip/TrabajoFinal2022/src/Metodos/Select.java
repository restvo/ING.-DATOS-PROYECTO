/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import Clases.*;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JC
 */
public class Select {
    
    public static List<EMPLEADO> obtenerEmpleados() throws Exception{
        List<EMPLEADO> listaEMPLEADOS = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM EMPLEADO";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int COD_EMPLEADO = rs.getInt("COD_EMPLEADO");
            String NOMBRE = rs.getString("NOMBRE");
            String CORREO = rs.getString("CORREO");
            int AÑOS_ANTIGUEDAD =rs.getInt("AÑOS_ANTIGUEDAD");
            EMPLEADO emp = new EMPLEADO(COD_EMPLEADO,NOMBRE,CORREO,AÑOS_ANTIGUEDAD);
            listaEMPLEADOS.add(emp);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaEMPLEADOS;
    }
    public static EMPLEADO obtenerEmpleado(int codigo) throws Exception{
        EMPLEADO e = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM EMPLEADO WHERE COD_EMPLEADO = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            int COD_EMPLEADO = rs.getInt("COD_EMPLEADO");
            String NOMBRE = rs.getString("NOMBRE");
            String CORREO = rs.getString("CORREO");
            int AÑOS_ANTIGUEDAD =rs.getInt("AÑOS_ANTIGUEDAD");
            e = new EMPLEADO(COD_EMPLEADO,NOMBRE,CORREO,AÑOS_ANTIGUEDAD);
        }
        rs.close();
        pst.close();
        conn.close();
        return e;
    }
    public static List<CAMION> obtenerCamiones() throws Exception{
        List<CAMION> listaCAMION = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM CAMION";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            String VIN = rs.getString("VIN");
            int COD_RUT = rs.getInt("COD_RUT");
            int COD_EMPLEADO = rs.getInt("COD_EMPLEADO");
            String MARCA = rs.getString("MARCA");
            String MODELO = rs.getString("MODELO");
            String DISPONIBILIDAD =rs.getString("DISPONIBILIDAD"); 
            int CAPACIDAD_MAXIMA = rs.getInt("CAPACIDAD_MAXIMA");
            CAMION cam = new CAMION(VIN,COD_RUT, COD_EMPLEADO,MARCA, MODELO,DISPONIBILIDAD,CAPACIDAD_MAXIMA);
            listaCAMION.add(cam);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaCAMION;
    }
    
    public static CAMION obtenerCamiones(int codigo) throws Exception{
        CAMION e = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM CAMIONES WHERE VIN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            String VIN = rs.getString("VIN");
            int COD_RUT = rs.getInt("COD_RUT");
            int COD_EMPLEADO = rs.getInt("COD_EMPLEADO");
            String MARCA = rs.getString("MARCA");
            String MODELO = rs.getString("MODELO");
            String DISPONIBILIDAD =rs.getString("DISPONIBILIDAD"); 
            int CAPACIDAD_MAXIMA = rs.getInt("CAPACIDAD_MAXIMA");
            e = new CAMION(VIN,COD_RUT, COD_EMPLEADO,MARCA, MODELO,DISPONIBILIDAD,CAPACIDAD_MAXIMA);    
        }
        rs.close();
        pst.close();
        conn.close();
        return e;
    }
    public static List<CLIENTE> obtenerCLIENTE() throws Exception{
        List<CLIENTE> listaCLIENTE = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM CLIENTE";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int RUC = rs.getInt("RUC");
            String CORREO = rs.getString("CORREO");
            String NOMBRE = rs.getString("NOMBRE");
            String RUBRO = rs.getString("RUBRO");
            CLIENTE cl = new CLIENTE(RUC,CORREO,NOMBRE,RUBRO);
            listaCLIENTE.add(cl);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaCLIENTE;
    }
    
    public static CLIENTE obtenerCLIENTE(int codigo) throws Exception{
        CLIENTE c = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM CLIENTE WHERE RUC = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            int RUC = rs.getInt("RUC");
            String CORREO = rs.getString("CORREO");
            String NOMBRE = rs.getString("NOMBRE");
            String RUBRO = rs.getString("RUBRO");
            c = new CLIENTE(RUC,CORREO,NOMBRE,RUBRO);    
        }
        rs.close();
        pst.close();
        conn.close();
        return c;
    }
    public static List<EVENTO> obtenerEVENTO() throws Exception{
        List<EVENTO> listaEVENTO = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM EVENTO";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int COD_EVENTO = rs.getInt("COD_EVENTO");
            int COD_RUT = rs.getInt("COD_RUT");;
            String DESCRIPCION_EVE = rs.getString("DESCRIPCION_EVE");
            int TIEMPO_ESPERA = rs.getInt("TIEMPO_ESPERA");
            EVENTO eve = new EVENTO(COD_EVENTO,COD_RUT,DESCRIPCION_EVE,TIEMPO_ESPERA);
            listaEVENTO.add(eve);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaEVENTO;
    }
    
    public static EVENTO obtenerEVENTO(int codigo) throws Exception{
        EVENTO t = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM EVENTO WHERE COD_RUT = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            int COD_EVENTO = rs.getInt("COD_EVENTO");
            int COD_RUT = rs.getInt("COD_RUT");
            String DESCRIPCION_EVE = rs.getString("DESCRIPCION_EVE");
            int TIEMPO_ESPERA = rs.getInt("TIEMPO_ESPERA");
            t = new EVENTO(COD_EVENTO,COD_RUT,DESCRIPCION_EVE,TIEMPO_ESPERA);   
        }
        rs.close();
        pst.close();
        conn.close();
        return t;
    }
    public static List<PEDIDO> obtenerPEDIDO() throws Exception{
        List<PEDIDO> listaPEDIDO = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM PEDIDO";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int CODIGO_PEDIDO = rs.getInt("CODIGO_PEDIDO");
            String TIPO_SERVICIO = rs.getString("TIPO_SERVICIO");
            String FECHA = rs.getString("FECHA");
            PEDIDO ped = new PEDIDO(CODIGO_PEDIDO,TIPO_SERVICIO,FECHA);
            listaPEDIDO.add(ped);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaPEDIDO;
    }
    
    public static PEDIDO obtenerPEDIDO(int codigo) throws Exception{
        PEDIDO p = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM PEDIDO WHERE CODIGO_PEDIDO = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            int CODIGO_PEDIDO = rs.getInt("CODIGO_PEDIDO");
            String TIPO_SERVICIO = rs.getString("TIPO_SERVICIO");
            String FECHA = rs.getString("FECHA");
            p = new PEDIDO(CODIGO_PEDIDO,TIPO_SERVICIO,FECHA);   
        }
        rs.close();
        pst.close();
        conn.close();
        return p;
    }
    public static List<RUTA> obtenerRUTA() throws Exception{
        List<RUTA> listaRUTA = new ArrayList<>();        
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM RUTA";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int COD_RUTA = rs.getInt("COD_RUTA");
            String TIPO = rs.getString("TIPO");
            int DURACION_RECORRIDO = rs.getInt("DURACION_RECORRIDO");
            RUTA ruta = new RUTA(COD_RUTA,TIPO,DURACION_RECORRIDO);
            listaRUTA.add(ruta);        
        }
        rs.close();
        pst.close();
        conn.close();
        return listaRUTA;
    }
    
    public static RUTA obtenerRUTA(int codigo) throws Exception{
        RUTA r = null;
        Connection conn = JdbcUtil.getConnection();
        String sql = "SELECT * FROM RUTA WHERE COD_RUTA = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, codigo);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
            int COD_RUTA = rs.getInt("COD_RUTA");
            String TIPO = rs.getString("TIPO");
            int DURACION_RECORRIDO = rs.getInt("DURACION_RECORRIDO");
            r = new RUTA(COD_RUTA,TIPO,DURACION_RECORRIDO);   
        }
        rs.close();
        pst.close();
        conn.close();
        return r;
    }
    
    
    public static void main(String[] args) throws Exception{
        List<EMPLEADO> empleados = obtenerEmpleados();
        System.out.println(empleados);
        
        EMPLEADO e = obtenerEmpleado(455);
        System.out.println(e.getNOMBRE());
        System.out.println(e.getCOD_EMPLEADO());
        System.out.println(e.getCORREO());
        System.out.println(e.getAÑOS_ANTIGUEDAD());
        
    }

}
