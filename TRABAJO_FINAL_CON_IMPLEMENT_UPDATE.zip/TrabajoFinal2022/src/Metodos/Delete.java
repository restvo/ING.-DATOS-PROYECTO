/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author JC
 */
public class Delete {
    public static void eliminarEMPLEADO(int cod) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM EMPLEADO WHERE COD_EMPLEADO = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, cod);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    }
  
    public static void eliminarCAMION(int VIN) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM CAMION WHERE VIN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, VIN);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    
}
        public static void eliminarCLIENTE(int RUC) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM CLIENTE WHERE RUC = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, RUC);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    }
        public static void eliminarEVENTO(int COD_EVENTO) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM EVENTO WHERE COD_EVENTO = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, COD_EVENTO);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    }
        public static void eliminarPEDIDO(int CODIGO_PEDIDO) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM PEDIDO WHERE CODIGO_PEDIDO = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, CODIGO_PEDIDO);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    }
        public static void eliminarRUTA(int COD_RUTA) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "DELETE FROM RUTA WHERE COD_RUTA = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, COD_RUTA);
        pst.executeUpdate();
        pst.close();        
        conn.close();
    }

    
    public static void main(String[] args) throws Exception{
        eliminarEMPLEADO(1);
        System.out.println("Empleado eliminado correctamente");
        eliminarCAMION(1);

    }
}
