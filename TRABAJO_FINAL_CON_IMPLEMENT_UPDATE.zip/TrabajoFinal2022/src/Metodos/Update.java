/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;


/**
 *
 * @author JC
 */
public class Update {   
    public static void actualizarEMPLEADO(int COD_EMPLEADO, String NOMBRE, String CORREO, int AÑOS_EXPERIENCIA) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE CLIENTE SET NOMBRE = ?, CORREO = ?, AÑOS_EXPERIENCIA = ? WHERE COD_EMPLEADO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,CORREO);
        pst.setString(2,NOMBRE);
        pst.setInt(3, AÑOS_EXPERIENCIA);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(4,COD_EMPLEADO);       
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();  
    }
    public static void actualizarCAMION(int VIN, String DISPONIBILIDAD,int CAPACIDAD_MAXIMA, int COD_EMPLEADO, int COD_RUT, String MARCA, String MODELO) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE CAMION SET DISPONIBILIDAD = ? WHERE VIN = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,DISPONIBILIDAD);
        
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,VIN);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarCLIENTE(int RUC, String CORREO, String NOMBRE, String RUBRO) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE CLIENTE SET CORREO = ?, NOMBRE = ?, RUBRO = ? WHERE RUC = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,CORREO);
        pst.setString(2,NOMBRE);
        pst.setString(3,RUBRO);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(4,RUC);       
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarEVENTO(int COD_EVENTO, String DESCRIPCION_EVE,int  COD_RUT,  int TIEMPO_ESPERA) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE EVENTO SET DESCRIPCION_EVE = ?, COD_RUT = ?, TIEMPO_ESPERA= ? WHERE COD_EVENTO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,DESCRIPCION_EVE);
        pst.setInt(2,COD_RUT);
        pst.setInt(3,TIEMPO_ESPERA);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(4,COD_EVENTO);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarPEDIDO(int CODIGO_PEDIDO, String TIPO_SERVICIO,String FECHA) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE PEDIDO SET TIPO_SERVICIO = ?, FECHA= ?, WHERE CODIGO_PEDIDO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,TIPO_SERVICIO);
        pst.setString(2,FECHA);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(3,CODIGO_PEDIDO);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarRUTA(int COD_RUTA, String NOMBRE,int DURACION_RECORRIDO ) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE RUTA SET NOMBRE = ?, DURACION_RECORRIDO=?,  WHERE COD_RUTA = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,NOMBRE);
        pst.setInt(1,DURACION_RECORRIDO);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,COD_RUTA);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    
    public static void main(String[] args) throws Exception{
        int RUC = 124234564;
        String CORREO = "prueba2@gmail.com";
        String NOMBRE = "PRUEBA2";
        String RUBRO = "NUEVO";
        
        actualizarCLIENTE(RUC , CORREO, NOMBRE, RUBRO);
        System.out.println("Datos actualizados correctamente");
    }
}
