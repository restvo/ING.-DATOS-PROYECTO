/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import Clases.*;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;


/**
 *
 * @author JC
 */
public class Insert {
    //ORM
    public static void registrarEMPLEADO(EMPLEADO emp) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO EMPLEADO VALUES(?, ?, ? ,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, emp.getCOD_EMPLEADO());
        pst.setString(2, emp.getNOMBRE());
        pst.setString(3, emp.getCORREO());
        pst.setInt(4, emp.getAÑOS_ANTIGUEDAD());
        pst.executeUpdate();
        pst.close();
        conn.close();
    }    
        public static void registrarCAMION(CAMION cam) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO CAMION VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1,cam.getVIN());
        pst.setInt(2,cam.getCOD_RUT());
        pst.setInt(3,cam.getCOD_EMPLEADO());
        pst.setString(4,cam.getMARCA());
        pst.setString(5,cam.getMODELO());
        pst.setString(6,cam.getDISPONIBILIDAD());
        pst.setInt(7,cam.getCAPACIDAD_MAXIMA());
        pst.executeUpdate();
        pst.close();
        conn.close();
       
    }    
    public static void registrarCLIENTE(CLIENTE cl) throws Exception{
        
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO CLIENTE VALUES(?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1,cl.getRUC());
        pst.setString(2,cl.getCORREO());
        pst.setString(3,cl.getNOMBRE());
        pst.setString(4,cl.getRUBRO());
        pst.executeUpdate();
        pst.close();
        conn.close();
       
    }    


    //ORM
    public static void registrarPEDIDO(PEDIDO ped) throws Exception{
        
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO PEDIDO VALUES(?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1,ped.getCODIGO_PEDIDO());
        pst.setString(2,ped.getTIPO_SERVICIO());
        pst.setString(3,ped.getFECHA());
        pst.executeUpdate();
        pst.close();
        conn.close();
       
    }    
    public static void registrarRUTA(RUTA rut) throws Exception{
        
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO RUTA VALUES(?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1,rut.getCOD_RUTA());
        pst.setString(2,rut.getNOMBRE());
        pst.setInt(3,rut.getDURACION_RECORRIDO());
        pst.executeUpdate();
        pst.close();
        conn.close();
       
    }    
    public static void registrarEVENTO(EVENTO eve) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO EVENTO VALUES( ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, eve.getCOD_EVENTO());
        pst.setInt(2, eve.getCOD_RUT());
        pst.setString(3, eve.getDESCRIPCION_EVE());
        pst.setInt(4, eve.getTIEMPO_ESPERA());
        pst.executeUpdate();
        pst.close();
        conn.close();
    }    


    public static void main(String[] args) throws Exception{
       /* EMPLEADO e1= new EMPLEADO(1,"Angel Ferroa Mejia","fer123@gmail.com",2);
        registrarEMPLEADO(e1);
        System.out.println("Empleado registrado correctamente");
        */  
    

       
        CAMION c1 = new CAMION("1GNSN13Z6M024523",902,1,"HYUNDAY","NEW","DISPONIBLE",19);
        registrarCAMION(c1);

        System.out.println("Camion registrado correctamente");

      
    }
}