/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;


/**
 *
 * @author JC
 */
public class Update {   
    public static void actualizarEMPLEADO(int cod, String correo) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE EMPLEADO SET CORREO = ? WHERE COD_EMPLEADO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,correo);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,cod);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarCAMION(int VIN, String DISPONIBILIDAD) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE CAMION SET DISPONIBILIDAD = ? WHERE VIN = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,DISPONIBILIDAD);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,VIN);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarCLIENTE(int RUC, String CORREO) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE CLIENTE SET CORREO = ? WHERE RUC = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,CORREO);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,RUC);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarEVENTO(int COD_EVENTO, String DESCRIPCION_EVE) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE EVENTO SET DESCRIPCION_EVE = ? WHERE COD_EVENTO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,DESCRIPCION_EVE);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,COD_EVENTO);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarPEDIDO(int CODIGO_PEDIDO, String TIPO_SERVICIO) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE PEDIDO SET TIPO_SERVICIO = ? WHERE CODIGO_PEDIDO = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,TIPO_SERVICIO);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,CODIGO_PEDIDO);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    public static void actualizarRUTA(int COD_RUTA, String TIPO) throws Exception{
        //Obtener el objeto conexion
        Connection conn = JdbcUtil.getConnection();
        //Definir la sentencia (como cadena)
        String sql = "UPDATE RUTA SET TIPO = ? WHERE COD_RUTA = ?";
        //Crear objeto Statement (PreparedStatement -> con parametros)
        PreparedStatement pst = conn.prepareStatement(sql);
        //Asignar valores a los parametros (indices a partir de 1)
        //Asignar el primer parametro (numerico con decimales)
        pst.setString(1,TIPO);
        //Asignar el segundo parametro(entero)
        //Ejecutar la consulta  
        pst.setInt(2,COD_RUTA);
        pst.executeUpdate();
        //Liberar recursos
        pst.close();        
        conn.close();       
    }
    
    public static void main(String[] args) throws Exception{
        int cod = 455;
        String correo = "prueba32@gmail.com";
        actualizarEMPLEADO(cod, correo);
        System.out.println("Datos actualizados correctamente");
    }
}
