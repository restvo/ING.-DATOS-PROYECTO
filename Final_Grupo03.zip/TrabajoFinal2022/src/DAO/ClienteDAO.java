/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Clases.CLIENTE;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Angel
 */
public class ClienteDAO {

    public void listarCliente(Connection conn, JTable tabla)
    {
        DefaultTableModel model; // Crea tabla
        
        // Crea columnas
        String [] columnas = {"RUC", "CORREO", "NOMBRE", "RUBRO"};
        model = new DefaultTableModel(null, columnas);
        
        // Crea sentencia SQL
        String sql = "SELECT * FROM CLIENTE";
        
        String [] filas = new String[4];
        Statement st = null; // Ejecuta el query
        ResultSet rs = null; // Obtiene el resultado del query
        
        // Muestra datos en la tabla
        try 
        {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) 
            {                
                for (int i = 0; i < 4; i++) 
                {
                    // Guarda datos en las filas
                    filas[i] = rs.getString(i+1);
                }
                model.addRow(filas); // Agrega datos a las filas
            }
            tabla.setModel(model); // Ejecuta el modelo
            
        } catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, "No es posible mostrar la tabla.");
        }
    }
    
}
