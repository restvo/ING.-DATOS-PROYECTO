/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import javax.swing.JOptionPane;

/**
 *
 * @author RICHARD
 */
public class MensajesErrorAndAdvertencia {
 public static String ErrorIngreso="Tenemos Error en el Ingreso de Datos";
 public static String ErrorFalta="Es obligatorio todo los campos";
 public static String inforDatEncon="Dato Encontrado en la DB";
 public static String InformDatosGuar="Datos Guardados en la DB ";
 
 public static String InformDNI="Ingrese el Numero de DNI";
 public static String InforSNumero="Ingrese Solo Numero";
 public static String InforLimite="Error  sobrepasa el Limite";
 public static String informDniExis="DNI ya Existe";
 public static String inforNomExis="El Aula ya tiene un Curso \n Desea Actualizar";
 public static String ErrorDNotExist="Codigo no Existe";
 public static String InforBuscar="Busca Datos en la DB primero";
 
 public static String InforActualAd="Esta seguro de actualizar los datos";
 public static String InforCancel="Se Cancelo la Operacion";
 public static String InforAct="Datos Actualizado ";
 
 public static String InforElimAd="Una vez que ayas eliminado \n no puedes volver a restaurarla";
 public static String InforElimnar="Dato Eliminado";
 
}
