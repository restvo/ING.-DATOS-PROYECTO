/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases.BO;

import DAO.EventoDAO;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JTable;

public class EventosBO {
    public EventoDAO eveDAO = new EventoDAO();
    
        public void listarEvento(JTable tabla)
    {
        Connection conn = JdbcUtil.getConnection();
        eveDAO.listarEvento(conn, tabla);
        try {
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
