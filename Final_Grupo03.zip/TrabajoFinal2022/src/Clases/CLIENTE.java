/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


public class CLIENTE {
    
    private int RUC;
    private String CORREO;
    private String NOMBRE;
    private String RUBRO;

    public CLIENTE(int RUC, String CORREO, String NOMBRE, String RUBRO) {
        this.RUC = RUC;
        this.CORREO = CORREO;
        this.NOMBRE = NOMBRE;
        this.RUBRO = RUBRO;
    }

    public int getRUC() {
        return RUC;
    }

    public String getCORREO() {
        return CORREO;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public String getRUBRO() {
        return RUBRO;
    }
    
    
}
