/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Angel
 */
public class EMPLEADO {

    private int COD_EMPLEADO;
    private String NOMBRE;
    public String CORREO;
    public int AÑOS_ANTIGUEDAD;
    public EMPLEADO(int COD_EMPLEADO, String NOMBRE, String CORREO,int AÑOS_ANTIGUEDAD){
        this.COD_EMPLEADO = COD_EMPLEADO;
        this.NOMBRE = NOMBRE;
        this.CORREO = CORREO;
        this.AÑOS_ANTIGUEDAD = AÑOS_ANTIGUEDAD;
        
    }

    
    /*public String toString(){
        return COD_EMPLEADO + NOMBRE + CORREO + AÑOS_ANTIGUEDAD;
    }
  */

    public int getCOD_EMPLEADO() {
        return COD_EMPLEADO;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public String getCORREO() {
        return CORREO;
    }

    public int getAÑOS_ANTIGUEDAD() {
        return AÑOS_ANTIGUEDAD;
    }
}
