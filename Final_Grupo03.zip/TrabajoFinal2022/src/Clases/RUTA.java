/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Angel
 */
public class RUTA {
    private int COD_RUTA;
    private String NOMBRE;
    private int DURACION_RECORRIDO;

    public RUTA(int COD_RUTA, String NOMBRE, int DURACION_RECORRIDO) {
        this.COD_RUTA = COD_RUTA;
        this.NOMBRE = NOMBRE;
        this.DURACION_RECORRIDO = DURACION_RECORRIDO;
    }

    public int getCOD_RUTA() {
        return COD_RUTA;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public int getDURACION_RECORRIDO() {
        return DURACION_RECORRIDO;
    }
    
    
    
    
}
